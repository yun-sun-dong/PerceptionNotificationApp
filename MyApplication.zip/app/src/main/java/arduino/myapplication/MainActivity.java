package arduino.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setButton();

    }

    private void setButton(){
        Button Time = (Button)findViewById(R.id.buttonTime);
        Button Alaram = (Button)findViewById(R.id.buttonAlarm);
        Button Pattern = (Button)findViewById(R.id.buttonPattern);
        Time.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(),TimeActivity.class);
                startActivity(intent);
            }

        });

        Alaram.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(),AlaramActivity.class);
                startActivity(intent);
            }

        });

        Pattern.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(),PatternActivity.class);
                startActivity(intent);
            }

        });
    }
}
